#!/bin/bash
# ============================================================
# tests/run.sh — syncctl test suite (no real cluster needed)
# ============================================================
# All tests use mock-api.sh + JSON fixtures
# Run: bash tools/syncctl/tests/run.sh
# ============================================================

set -u

TESTS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SYNCCTL_DIR="$(cd "$TESTS_DIR/.." && pwd)"
LIB_DIR="$SYNCCTL_DIR/lib"
SSOT="${SSOT:-$HOME/bashscripts}"

# Source 01-colors.sh for cn()/c() helpers (lib/renderer.sh, lib/doctor.sh need them)
[[ -f "$SSOT/01-colors.sh" ]] && source "$SSOT/01-colors.sh"

# Test counters
PASS=0
FAIL=0
FAILED_TESTS=()

# Color (V4: use helpers from 01-colors.sh — functions, not vars)
_R_OK()    { cn 46  b "$@"; }
_R_ERR()   { cn 196 b "$@"; }
_R_INFO()  { cn 75  b "$@"; }
_R_DIM()   { cn 244 d "$@"; }
_R_ERR()   { cn 196 b "$@"; }
_R_INFO()  { cn 75  b "$@"; }
_R_DIM()   { cn 244 d "$@"; }

_assert_eq() {
    local label="$1" expected="$2" actual="$3"
    if [[ "$expected" == "$actual" ]]; then
        printf "  ${_R_OK}✓${_R_RESET} %s\n" "$label"
        (( PASS++ )) || true
    else
        printf "  ${_R_ERR}✗${_R_RESET} %s\n" "$label"
        printf "      expected: %q\n" "$expected"
        printf "      actual:   %q\n" "$actual"
        (( FAIL++ )) || true
        FAILED_TESTS+=("$label")
    fi
}

_assert_contains() {
    local label="$1" needle="$2" haystack="$3"
    if [[ "$haystack" == *"$needle"* ]]; then
        printf "  ${_R_OK}✓${_R_RESET} %s\n" "$label"
        (( PASS++ )) || true
    else
        printf "  ${_R_ERR}✗${_R_RESET} %s\n" "$label"
        printf "      needle:   %q\n" "$needle"
        printf "      haystack: %q\n" "$haystack"
        (( FAIL++ )) || true
        FAILED_TESTS+=("$label")
    fi
}

_setup() {
    local fixture_name="$1"
    # Isolate state per test
    export SYNCCTL_HOME="$(mktemp -d)"
    export SYNCCTL_STATE="$SYNCCTL_HOME/state.json"
    export SYNCCTL_LOCK_FILE="$SYNCCTL_HOME/syncctl.lock"
    export SYNCCTL_AUDIT_LOG="$SYNCCTL_HOME/audit.log"
    export SYNCCTL_CHECKPOINT_DIR="$SYNCCTL_HOME/checkpoints"
    export SYNCCTL_CONFLICT_ARCHIVE="$SYNCCTL_HOME/conflicts"
    export SYNCCTL_LOCAL_MASTER_FILE="$SYNCCTL_HOME/master"
    export SYNCCTL_FOLDER_ROOT="$(mktemp -d)"
    export SYNCCTL_SYNCED_MASTER_DIR="$SYNCCTL_FOLDER_ROOT/.syncctl"
    export SYNCCTL_SYNCED_MASTER_FILE="$SYNCCTL_SYNCED_MASTER_DIR/master"
    export SYNCCTL_MOCK_DIR="$TESTS_DIR/fixtures/$fixture_name"
    export JOE_ENV="WSL"

    # IMPORTANT: source config.sh FIRST so the loaded guard is set.
    # Otherwise config.sh's `declare -gA ... =()` will clear our test arrays.
    source "$LIB_DIR/config.sh"

    # Source 01-colors.sh for cn() / c() helpers (renderer.sh needs them)
    [[ -f "$SSOT/01-colors.sh" ]] && source "$SSOT/01-colors.sh"

    # Unset anything config.sh auto-populated from env (NODE_*_ST_ID from
    # the interactive shell would otherwise add devices like 'mumu').
    unset SYNCCTL_DEVICES SYNCCTL_API_URLS SYNCCTL_API_KEYS

    # Now set our test-specific 3-device cluster
    declare -gA SYNCCTL_DEVICES=(
        [wsl]="3S42YWK-FAKE-WSL-ID"
        [windows]="FJXVHAJ-FAKE-WIN-ID"
        [termux]="2KJ2HQ3-FAKE-TM-ID"
    )
    declare -gA SYNCCTL_API_URLS=(
        [wsl]="http://wsl:8385"
        [windows]="http://window:8384"
        [termux]="http://termux:8383"
    )
    declare -gA SYNCCTL_API_KEYS=(
        [wsl]="fake-wsl-key"
        [windows]="fake-win-key"
        [termux]="fake-tm-key"
    )
    export SYNCCTL_LOCAL_DEVICE="wsl"
    export SYNCCTL_LOCAL_API_URL="http://wsl:8385"
    export SYNCCTL_LOCAL_API_KEY="fake-wsl-key"

    # Load mock instead of real api
    source "$LIB_DIR/mock.sh"
}

_teardown() {
    rm -rf "$SYNCCTL_HOME" "$SYNCCTL_FOLDER_ROOT" 2>/dev/null
    unset SYNCCTL_DEVICES SYNCCTL_API_URLS SYNCCTL_API_KEYS
    unset _SYNCCTL_LOCK_DIR
}

# ──────────────────────────────────────────────────────────
# Test 1: status on clean cluster (WSL = master)
# ──────────────────────────────────────────────────────────
test_status_clean() {
    printf "\n${_R_BOLD}TEST: status (clean cluster, WSL master)${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/ownership.sh"
    source "$LIB_DIR/renderer.sh"

    # Pre-seed local master
    state_set_local_master "wsl"

    local out
    out="$(render_status 2>&1)"
    _assert_contains "shows wsl as master" "wsl" "$out"
    _assert_contains "shows MASTER role" "MASTER" "$out"
    _assert_contains "shows folder type sendonly" "sendonly" "$out"
    _assert_contains "shows checkpoint section" "CHECKPOINT" "$out"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 2: who command
# ──────────────────────────────────────────────────────────
test_who() {
    printf "\n${_R_BOLD}TEST: who (returns master)${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/renderer.sh"
    state_set_local_master "wsl"

    local out
    out="$(render_who)"
    _assert_eq "returns WSL" "MASTER: wsl" "$out"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 3: checkpoint on clean cluster → pass
# ──────────────────────────────────────────────────────────
test_checkpoint_pass() {
    printf "\n${_R_BOLD}TEST: checkpoint (clean → pass)${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/checkpoint.sh"
    source "$LIB_DIR/renderer.sh"
    state_set_local_master "wsl"

    if checkpoint_run "wsl"; then
        printf "  ${_R_OK}✓${_R_RESET} checkpoint returns 0\n"
        (( PASS++ )) || true
    else
        printf "  ${_R_ERR}✗${_R_RESET} checkpoint should pass\n"
        (( FAIL++ )) || true
    fi
    _assert_eq "checkpoint ID is 4-digit" "0001" "$SYNCCTL_CHECKPOINT_ID"
    _assert_eq "result is pass" "pass" "$SYNCCTL_CHECKPOINT_RESULT"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 4: checkpoint fail → no master change
# ──────────────────────────────────────────────────────────
test_checkpoint_fail() {
    printf "\n${_R_BOLD}TEST: checkpoint fail → no master change${_R_RESET}\n"
    _setup "cluster-conflict"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/checkpoint.sh"
    state_set_local_master "wsl"

    # Need to create the .sync-conflict-* file
    touch "$SYNCCTL_FOLDER_ROOT/test.sync-conflict-2026-08-03-120000.sh"

    if checkpoint_run "wsl"; then
        printf "  ${_R_ERR}✗${_R_RESET} checkpoint should FAIL\n"
        (( FAIL++ )) || true
    else
        printf "  ${_R_OK}✓${_R_RESET} checkpoint correctly fails\n"
        (( PASS++ )) || true
    fi
    _assert_eq "result is fail" "fail" "$SYNCCTL_CHECKPOINT_RESULT"

    # Master should still be wsl
    local m; m="$(state_get_local_master)"
    _assert_eq "master unchanged" "wsl" "$m"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 5: transfer dry-run
# ──────────────────────────────────────────────────────────
test_transfer_dry_run() {
    printf "\n${_R_BOLD}TEST: transfer --dry-run${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/checkpoint.sh"
    source "$LIB_DIR/ownership.sh"
    source "$LIB_DIR/handover.sh"
    source "$LIB_DIR/renderer.sh"
    state_set_local_master "wsl"

    local out
    out="$(transfer_master windows --dry-run 2>&1)"
    _assert_contains "shows DRY RUN" "DRY RUN" "$out"
    _assert_contains "shows current master" "wsl" "$out"
    _assert_contains "shows target" "windows" "$out"
    _assert_contains "shows no changes applied" "No changes applied" "$out"

    # Master should not have changed
    local m; m="$(state_get_local_master)"
    _assert_eq "master unchanged after dry-run" "wsl" "$m"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 6: transfer idempotency
# ──────────────────────────────────────────────────────────
test_transfer_idempotent() {
    printf "\n${_R_BOLD}TEST: transfer to same device = noop${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/handover.sh"
    state_set_local_master "wsl"

    local out
    out="$(transfer_master wsl 2>&1)"
    _assert_contains "says already master" "already MASTER" "$out"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 7: full transfer (WSL → windows)
# ──────────────────────────────────────────────────────────
test_full_transfer() {
    printf "\n${_R_BOLD}TEST: full transfer (wsl → windows)${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/checkpoint.sh"
    source "$LIB_DIR/ownership.sh"
    source "$LIB_DIR/handover.sh"
    source "$LIB_DIR/renderer.sh"
    state_set_local_master "wsl"

    if transfer_master windows --reason "test" 2>&1; then
        printf "  ${_R_OK}✓${_R_RESET} transfer returns 0\n"
        (( PASS++ )) || true
    else
        printf "  ${_R_ERR}✗${_R_RESET} transfer should succeed\n"
        (( FAIL++ )) || true
    fi

    # Master should now be windows
    local m; m="$(state_get_local_master)"
    _assert_eq "master is now windows" "windows" "$m"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 8: lock prevents concurrent
# ──────────────────────────────────────────────────────────
test_lock() {
    printf "\n${_R_BOLD}TEST: lock prevents concurrent access${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/lock.sh"

    if lock_acquire; then
        printf "  ${_R_OK}✓${_R_RESET} first lock acquired\n"
        (( PASS++ )) || true
    else
        printf "  ${_R_ERR}✗${_R_RESET} first lock should succeed\n"
        (( FAIL++ )) || true
    fi

    if lock_acquire; then
        printf "  ${_R_ERR}✗${_R_RESET} second lock should FAIL\n"
        (( FAIL++ )) || true
    else
        printf "  ${_R_OK}✓${_R_RESET} second lock correctly rejected\n"
        (( PASS++ )) || true
    fi

    lock_release
    if lock_acquire; then
        printf "  ${_R_OK}✓${_R_RESET} can re-acquire after release\n"
        (( PASS++ )) || true
        lock_release
    fi

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 9: state reconcile (local vs synced)
# ──────────────────────────────────────────────────────────
test_state_reconcile() {
    printf "\n${_R_BOLD}TEST: state reconcile (local vs synced)${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"

    # Both empty
    local r; r="$(state_reconcile_master)"
    _assert_contains "uninit when both empty" "uninitialized" "$r"

    # Only local
    state_set_local_master "wsl"
    r="$(state_reconcile_master)"
    _assert_contains "local only" "master=wsl" "$r"

    # Both same
    state_set_synced_master "wsl"
    r="$(state_reconcile_master)"
    _assert_contains "both same" "master=wsl" "$r"

    # Disagree
    state_set_synced_master "windows"
    r="$(state_reconcile_master)"
    _assert_contains "disagree → prefer synced" "master=windows" "$r"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Test 10: doctor
# ──────────────────────────────────────────────────────────
test_doctor() {
    printf "\n${_R_BOLD}TEST: doctor runs without error${_R_RESET}\n"
    _setup "cluster-clean"
    source "$LIB_DIR/state.sh"
    source "$LIB_DIR/doctor.sh"
    state_set_local_master "wsl"

    local out
    out="$(doctor_run 2>&1)"
    _assert_contains "doctor prints banner" "syncctl doctor" "$out"
    _assert_contains "doctor checks CRLF" "CRLF" "$out"
    _assert_contains "doctor checks master" "Master state" "$out"
    _assert_contains "doctor checks API" "API reachability" "$out"

    _teardown
}

# ──────────────────────────────────────────────────────────
# Run all
# ──────────────────────────────────────────────────────────
main() {
    printf "${_R_BOLD}═══════════════════════════════════════════════════════════${_R_RESET}\n"
    printf "${_R_BOLD}  syncctl test suite${_R_RESET}\n"
    printf "${_R_BOLD}═══════════════════════════════════════════════════════════${_R_RESET}\n"

    test_status_clean
    test_who
    test_checkpoint_pass
    test_checkpoint_fail
    test_transfer_dry_run
    test_transfer_idempotent
    test_full_transfer
    test_lock
    test_state_reconcile
    test_doctor

    printf "\n${_R_BOLD}═══════════════════════════════════════════════════════════${_R_RESET}\n"
    if (( FAIL == 0 )); then
        printf "${_R_OK}  All %d tests passed ✓${_R_RESET}\n" "$PASS"
        exit 0
    else
        printf "${_R_ERR}  %d passed, %d FAILED${_R_RESET}\n" "$PASS" "$FAIL"
        printf "${_R_DIM}  Failed: %s${_R_RESET}\n" "${FAILED_TESTS[*]}"
        exit 1
    fi
}

main
