#!/bin/bash
# ============================================================
# syncctl/lib/ownership.sh — Set folder type on each device
# ============================================================
# Wraps set_folder_type from api.sh with logging + safety.
# Each function is small + idempotent.
# ============================================================

# Guard
[[ -n "${_SYNCCTL_OWNERSHIP_LOADED:-}" ]] && return 0
export _SYNCCTL_OWNERSHIP_LOADED=1

source "$(dirname "${BASH_SOURCE[0]}")/config.sh"
source "$(dirname "${BASH_SOURCE[0]}")/api.sh"
source "$(dirname "${BASH_SOURCE[0]}")/state.sh"

# Make a device the Master (sendonly)
# Other devices untouched.
promote_to_master() {
    local dev="$1"
    if ! syncctl_is_known_device "$dev"; then
        echo "ownership: unknown device '$dev'" >&2
        return 1
    fi
    if ! set_folder_type "$dev" "sendonly"; then
        echo "ownership: failed to set $dev=sendonly: $SYNCCTL_API_ERR" >&2
        return 1
    fi
    audit_log "ownership" "action=promote" "device=$dev" "type=sendonly"
    return 0
}

# Demote a device from Master (receiveonly)
demote_from_master() {
    local dev="$1"
    if ! syncctl_is_known_device "$dev"; then
        echo "ownership: unknown device '$dev'" >&2
        return 1
    fi
    if ! set_folder_type "$dev" "receiveonly"; then
        echo "ownership: failed to set $dev=receiveonly: $SYNCCTL_API_ERR" >&2
        return 1
    fi
    audit_log "ownership" "action=demote" "device=$dev" "type=receiveonly"
    return 0
}

# Apply full ownership: target = sendonly, all others = receiveonly
apply_ownership() {
    local master="$1"
    local dev
    local ok=1

    for dev in $(syncctl_list_devices); do
        if [[ "$dev" == "$master" ]]; then
            promote_to_master "$dev" || ok=0
        else
            demote_from_master "$dev" || ok=0
        fi
    done

    return $(( 1 - ok ))
}

# Read current folder type for a device
# Echoes: sendonly | receiveonly | sendreceive | unknown
get_folder_type() {
    local dev="$1"
    if ! get_folder_config "$dev" >/dev/null 2>&1; then
        echo "unknown"
        return 1
    fi
    echo "$SYNCCTL_API_BODY" | jq -r '.type // "unknown"' 2>/dev/null || echo "unknown"
}

# Show ownership table
ownership_table() {
    local dev master
    master="$(state_reconcile_master | sed -n 's/^master=//p' | cut -d'|' -f1)"

    printf '%-10s %-14s %s\n' "DEVICE" "TYPE" "ROLE"
    printf '%-10s %-14s %s\n' "----------" "--------------" "----"
    for dev in $(syncctl_list_devices); do
        local type role
        type="$(get_folder_type "$dev")"
        if [[ "$dev" == "$master" ]]; then
            role="MASTER"
        else
            role="REPLICA"
        fi
        printf '%-10s %-14s %s\n' "$dev" "$type" "$role"
    done
}
