#!/bin/bash
# ============================================================
# syncctl/lib/state.sh — Master cache + handover state
# ============================================================
# Two storage layers:
#   1. Local cache  → ~/.local/share/syncctl/master
#   2. Local state  → ~/.local/share/syncctl/state.json
#   3. Synced SSOT  → $SSOT/.syncctl/master (read-only here)
#
# Design decision 23.1 (Hybrid storage with reconcile)
# ============================================================

# Guard
[[ -n "${_SYNCCTL_STATE_LOADED:-}" ]] && return 0
export _SYNCCTL_STATE_LOADED=1

# Source config (paths)
source "$(dirname "${BASH_SOURCE[0]}")/config.sh"

# ──────────────────────────────────────────────────────────
# Local master cache: ~/.local/share/syncctl/master
# Plain text. One line. Just the device name.
# ──────────────────────────────────────────────────────────

# Read local cache. Echoes device name or empty.
state_get_local_master() {
    [[ -f "$SYNCCTL_LOCAL_MASTER_FILE" ]] || return 0
    head -1 "$SYNCCTL_LOCAL_MASTER_FILE" 2>/dev/null
}

# Write local cache.
state_set_local_master() {
    local dev="$1"
    syncctl_init_paths
    printf '%s\n' "$dev" > "$SYNCCTL_LOCAL_MASTER_FILE"
}

# ──────────────────────────────────────────────────────────
# Synced SSOT: $SSOT/.syncctl/master
# Plain text. One line. Just the device name.
# This is what gets synced across all devices.
# ──────────────────────────────────────────────────────────

# Read synced SSOT. Echoes device name or empty.
state_get_synced_master() {
    [[ -f "$SYNCCTL_SYNCED_MASTER_FILE" ]] || return 0
    head -1 "$SYNCCTL_SYNCED_MASTER_FILE" 2>/dev/null
}

# Write synced SSOT. Creates .syncctl/ if missing.
state_set_synced_master() {
    local dev="$1"
    mkdir -p "$SYNCCTL_SYNCED_MASTER_DIR"
    printf '%s\n' "$dev" > "$SYNCCTL_SYNCED_MASTER_FILE"
    # Add a guard file so Syncthing doesn't ignore the dir
    [[ -f "$SYNCCTL_SYNCED_MASTER_DIR/.keep" ]] || \
        printf '# syncctl master pointer (auto-generated, do not edit)\n' \
        > "$SYNCCTL_SYNCED_MASTER_DIR/.keep"
}

# ──────────────────────────────────────────────────────────
# Reconcile: pick authoritative master value
# Outputs: "master=<dev>|source=<local|synced|default>"
# Returns: 0 always
# ──────────────────────────────────────────────────────────
state_reconcile_master() {
    local local_m synced_m result_dev result_src="synced"

    local_m="$(state_get_local_master)"
    synced_m="$(state_get_synced_master)"

    # Both missing → uninitialized
    if [[ -z "$local_m" && -z "$synced_m" ]]; then
        printf 'master=|source=uninitialized\n'
        return 0
    fi

    # Only synced → use synced (new device joining)
    if [[ -z "$local_m" && -n "$synced_m" ]]; then
        state_set_local_master "$synced_m"
        printf 'master=%s|source=synced\n' "$synced_m"
        return 0
    fi

    # Only local → use local (initial state, hasn't synced yet)
    if [[ -n "$local_m" && -z "$synced_m" ]]; then
        printf 'master=%s|source=local\n' "$local_m"
        return 0
    fi

    # Both exist, agree → use it
    if [[ "$local_m" == "$synced_m" ]]; then
        printf 'master=%s|source=both\n' "$local_m"
        return 0
    fi

    # Disagree → prefer synced, WARN
    state_set_local_master "$synced_m"
    printf 'master=%s|source=synced_warning|local_was=%s\n' "$synced_m" "$local_m"
    return 0
}

# ──────────────────────────────────────────────────────────
# state.json — durable handover state (atomic read/write)
# Uses flock for safety.
# ──────────────────────────────────────────────────────────
state_json_get() {
    local key="$1"
    [[ -f "$SYNCCTL_STATE" ]] || { printf ''; return 0; }
    jq -r --arg k "$key" '.[$k] // empty' "$SYNCCTL_STATE" 2>/dev/null
}

state_json_set() {
    local key="$1" value="$2"
    syncctl_init_paths
    local tmp; tmp="$(mktemp)"
    if [[ -f "$SYNCCTL_STATE" ]]; then
        jq --arg k "$key" --arg v "$value" '.[$k] = $v' "$SYNCCTL_STATE" > "$tmp" 2>/dev/null || {
            rm -f "$tmp"
            # Init if jq failed (e.g. corrupt file)
            jq -n --arg k "$key" --arg v "$value" '{($k):$v}' > "$tmp"
        }
    else
        jq -n --arg k "$key" --arg v "$value" '{($k):$v}' > "$tmp"
    fi
    mv "$tmp" "$SYNCCTL_STATE"
}

state_json_init_if_missing() {
    syncctl_init_paths
    if [[ ! -f "$SYNCCTL_STATE" ]] || ! jq -e . "$SYNCCTL_STATE" >/dev/null 2>&1; then
        jq -n '{
            handover_in_progress: false,
            from: null,
            to: null,
            step: 0,
            started_at: null,
            checkpoint_id: null
        }' > "$SYNCCTL_STATE"
    fi
}

# Mark handover started
state_handover_begin() {
    local from="$1" to="$2" step="$3" chk_id="$4"
    state_json_init_if_missing
    state_json_set handover_in_progress true
    state_json_set from "$from"
    state_json_set to "$to"
    state_json_set step "$step"
    state_json_set started_at "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    state_json_set checkpoint_id "$chk_id"
}

state_handover_step() {
    state_json_set step "$1"
}

state_handover_complete() {
    state_json_init_if_missing
    state_json_set handover_in_progress false
    state_json_set from null
    state_json_set to null
    state_json_set step 0
    state_json_set started_at null
    state_json_set checkpoint_id null
}

# Check if handover is stale (started > timeout seconds ago and still in_progress)
state_handover_is_stale() {
    local started_at
    started_at="$(state_json_get started_at)"
    [[ -z "$started_at" ]] && return 1
    local now started_epoch
    now="$(date +%s)"
    # Parse ISO timestamp (best effort)
    if command -v gdate >/dev/null 2>&1; then
        started_epoch="$(gdate -d "$started_at" +%s 2>/dev/null)" || return 1
    else
        # GNU date on Linux
        started_epoch="$(date -d "$started_at" +%s 2>/dev/null)" || return 1
    fi
    (( now - started_epoch > SYNCCTL_HANDOVER_STALE_TIMEOUT ))
}

# ──────────────────────────────────────────────────────────
# Audit log
# ──────────────────────────────────────────────────────────
audit_log() {
    local event="$1"
    shift
    syncctl_init_paths
    local ts
    ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
    local extra="$*"
    # If first arg is a JSON object, merge it
    if [[ "${1:-}" =~ ^\{ ]]; then
        local obj="$1"
        shift
        local rest="$*"
        # Strip trailing args after first JSON
        printf '{"ts":"%s","event":"%s",%s}\n' "$ts" "$event" "${obj#\{}" \
            >> "$SYNCCTL_AUDIT_LOG"
    else
        printf '{"ts":"%s","event":"%s","detail":"%s"}\n' "$ts" "$event" "$*" \
            >> "$SYNCCTL_AUDIT_LOG"
    fi
}
