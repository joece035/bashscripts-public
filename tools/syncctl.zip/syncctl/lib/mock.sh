#!/bin/bash
# ============================================================
# syncctl/lib/mock.sh — Mock Syncthing API for testing
# ============================================================
# Override api_call to return canned responses from fixtures.
# Usage:
#   export SYNCCTL_MOCK_DIR="$PWD/tools/syncctl/tests/fixtures/cluster-clean"
#   source tools/syncctl/lib/mock.sh
#   syncctl status   # uses mock, no real network
#
# Fixture layout:
#   $SYNCCTL_MOCK_DIR/
#     <device>/<METHOD>-<path>.json
#   Example:
#     wsl/GET-/rest/system/status.json
#     wsl/PATCH-/rest/config/folders/bashscripts.json
#     windows/GET-/rest/db/completion.json
# ============================================================

# Guard
[[ -n "${_SYNCCTL_MOCK_LOADED:-}" ]] && return 0
export _SYNCCTL_MOCK_LOADED=1

# Load api.sh first to get the helper functions (api_device, get_folder_config, etc.)
# Then we override api_call below — bash will use this mock version.
source "$(dirname "${BASH_SOURCE[0]}")/api.sh"

# Override the high-level api_call
api_call() {
    local method="$1" base_url="$2" api_key="$3" path="$4" data="${5:-}"
    SYNCCTL_API_ERR="" SYNCCTL_API_HTTP="000" SYNCCTL_API_BODY=""

    # Find which device this URL maps to
    local dev=""
    if [[ "$JOE_ENV" == "WSL" || "$JOE_ENV" == "GIT-BASH" || "$JOE_ENV" == "TERMUX" || "$JOE_ENV" == "MUMU" ]]; then
        for d in "${!SYNCCTL_API_URLS[@]}"; do
            if [[ "${SYNCCTL_API_URLS[$d]}" == "$base_url" ]]; then
                dev="$d"; break
            fi
        done
    fi
    [[ -z "$dev" ]] && { SYNCCTL_API_ERR="mock: no device for $base_url"; return 1; }

    # Look for: $SYNCCTL_MOCK_DIR/$dev/$METHOD-$path.json
    # Normalize path: strip leading /, then replace /, ?, &, = with -
    # so /rest/db/completion?folder=foo → rest-db-completion-folder-foo
    local norm="${method}-${path#/}"
    norm="${norm//\//-}"
    norm="${norm//\?/-}"
    norm="${norm//\&/-}"
    norm="${norm//=/-}"
    local fixture="$SYNCCTL_MOCK_DIR/$dev/$norm.json"

    # Also try: without the api_key (ignore for matching)
    # Some fixtures use a "default" response — try that
    if [[ ! -f "$fixture" ]]; then
        fixture="$SYNCCTL_MOCK_DIR/$dev/_default.json"
    fi

    if [[ ! -f "$fixture" ]]; then
        SYNCCTL_API_ERR="mock: no fixture $dev/$norm.json (and no _default)"
        SYNCCTL_API_HTTP="404"
        return 1
    fi

    # Optional: inject dynamic behavior via _before.fixture
    if [[ -f "$SYNCCTL_MOCK_DIR/_before.sh" ]]; then
        # shellcheck source=/dev/null
        source "$SYNCCTL_MOCK_DIR/_before.sh"
    fi

    # Inject error from env if set
    if [[ -n "${MOCK_FAIL:-}" ]]; then
        SYNCCTL_API_ERR="$MOCK_FAIL"
        SYNCCTL_API_HTTP="503"
        MOCK_FAIL=""
        return 1
    fi

    SYNCCTL_API_BODY="$(cat "$fixture")"
    SYNCCTL_API_HTTP="200"
    return 0
}

# Log helper
mock_log() {
    [[ "${MOCK_VERBOSE:-0}" == "1" ]] && echo "[mock] $*" >&2
}
