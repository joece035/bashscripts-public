#!/bin/bash
# ============================================================
# syncctl/lib/handover.sh — Master handover (transfer/init)
# ============================================================
# Two-phase commit per spec section 23.4.
# Always:
#   1. Acquire lock
#   2. Check stale state (recovery menu if stale)
#   3. Run pre-checkpoint
#   4. Set state.json = HANDOVER_IN_PROGRESS
#   5. PHASE A: re-verify target in-sync, set state.step
#   6. PHASE B: promote target FIRST, then demote others
#   7. Update .syncctl/master
#   8. Run post-checkpoint
#   9. Clear state.json
#  10. Release lock
# ============================================================

# Guard
[[ -n "${_SYNCCTL_HANDOVER_LOADED:-}" ]] && return 0
export _SYNCCTL_HANDOVER_LOADED=1

source "$(dirname "${BASH_SOURCE[0]}")/config.sh"
source "$(dirname "${BASH_SOURCE[0]}")/api.sh"
source "$(dirname "${BASH_SOURCE[0]}")/state.sh"
source "$(dirname "${BASH_SOURCE[0]}")/lock.sh"
source "$(dirname "${BASH_SOURCE[0]}")/checkpoint.sh"
source "$(dirname "${BASH_SOURCE[0]}")/ownership.sh"

# ──────────────────────────────────────────────────────────
# init_master <device>
# First-time setup: assume no master exists yet
# ──────────────────────────────────────────────────────────
init_master() {
    local target="$1"
    local reason="${2:-first-time-setup}"

    if ! syncctl_is_known_device "$target"; then
        echo "init: unknown device '$target'" >&2
        return 1
    fi

    # Check if already initialized
    local existing
    existing="$(state_reconcile_master | sed -n 's/^master=//p' | cut -d'|' -f1)"
    if [[ -n "$existing" ]]; then
        echo "init: already initialized, master=$existing" >&2
        echo "  use 'syncctl transfer $target' instead" >&2
        return 1
    fi

    lock_acquire || return 1
    trap 'lock_release' RETURN

    echo "Initializing master = $target"

    # 1. Pre-checkpoint
    if ! checkpoint_run "$target"; then
        echo "⛔ INIT FAILED — pre-checkpoint did not pass" >&2
        echo "  Reason: $SYNCCTL_CHECKPOINT_REASON" >&2
        return 1
    fi
    local chk_id="$SYNCCTL_CHECKPOINT_ID"

    # 2. Set state
    state_handover_begin "" "$target" 1 "$chk_id"

    # 3. Apply ownership: target=sendonly, others=receiveonly
    if ! apply_ownership "$target"; then
        echo "⛔ INIT FAILED — could not apply ownership" >&2
        state_handover_complete
        return 1
    fi

    # 4. Write master pointers
    state_set_local_master "$target"
    state_set_synced_master "$target"

    # 5. Post-checkpoint
    if ! checkpoint_run "$target"; then
        echo "⚠️  INIT: post-checkpoint failed (but state is set)" >&2
    fi

    # 6. Clear state
    state_handover_complete

    audit_log "init" "master=$target" "reason=$reason" "checkpoint=#$chk_id"
    echo "✅ Master initialized: $target (checkpoint #$chk_id)"
    return 0
}

# ──────────────────────────────────────────────────────────
# transfer_master <target_device> [--force] [--reason "..."] [--dry-run]
# ──────────────────────────────────────────────────────────
transfer_master() {
    local target="" force=0 dry_run=0 reason=""
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --force) force=1; shift ;;
            --dry-run) dry_run=1; shift ;;
            --reason) reason="$2"; shift 2 ;;
            *) target="$1"; shift ;;
        esac
    done

    if [[ -z "$target" ]]; then
        echo "transfer: missing target device" >&2
        return 1
    fi
    if ! syncctl_is_known_device "$target"; then
        echo "transfer: unknown device '$target'" >&2
        return 1
    fi

    # Idempotency: already master?
    local current
    current="$(state_reconcile_master | sed -n 's/^master=//p' | cut -d'|' -f1)"
    if [[ "$current" == "$target" ]]; then
        echo "✓ $target is already MASTER" >&2
        echo "No action required."
        return 0
    fi

    # ─── Recovery check: stale handover? ───
    if state_json_get handover_in_progress 2>/dev/null | grep -qi true; then
        if state_handover_is_stale; then
            echo "⛔ STALE HANDOVER DETECTED"
            echo "  Started: $(state_json_get started_at)"
            echo "  From: $(state_json_get from) → To: $(state_json_get to)"
            echo "  Last step: $(state_json_get step)"
            echo ""
            echo "Run 'syncctl recover' to resolve."
            return 1
        fi
    fi

    # ─── Force mode handling ───
    if [[ "$force" == "1" ]]; then
        # Check that current master is actually offline
        if [[ -n "$current" ]] && get_completion "$current" >/dev/null 2>&1; then
            echo "⛔ --force rejected: current master ($current) is ONLINE" >&2
            echo "  --force is for break-glass only when master is offline" >&2
            return 1
        fi
        if [[ -z "$reason" ]]; then
            echo "⛔ --force requires --reason" >&2
            return 1
        fi
        echo "⚠️  FORCE TRANSFER (break-glass)"
        echo "  Current master: ${current:-NONE} (offline)"
        echo "  Target: $target"
        echo "  Reason: $reason"
        echo ""
        local confirm
        read -r -p 'Type "FORCE TRANSFER" to continue: ' confirm
        if [[ "$confirm" != "FORCE TRANSFER" ]]; then
            echo "Aborted."
            return 1
        fi
    fi

    # ─── Dry run ───
    if [[ "$dry_run" == "1" ]]; then
        echo "DRY RUN"
        echo "  Current Master: $current"
        echo "  Target Master:  $target"
        echo ""
        # Quick checkpoint
        if checkpoint_run "$current" 2>/dev/null; then
            echo "  Checkpoint:     PASS (#$SYNCCTL_CHECKPOINT_ID)"
        else
            echo "  Checkpoint:     FAIL ($SYNCCTL_CHECKPOINT_REASON)"
        fi
        echo ""
        echo "Planned changes:"
        for dev in $(syncctl_list_devices); do
            if [[ "$dev" == "$current" && "$dev" != "$target" ]]; then
                echo "  $dev  SEND ONLY → RECEIVE ONLY"
            elif [[ "$dev" == "$target" ]]; then
                echo "  $dev  RECEIVE ONLY → SEND ONLY"
            else
                echo "  $dev  RECEIVE ONLY (unchanged)"
            fi
        done
        echo ""
        echo "No changes applied."
        return 0
    fi

    # ─── Real transfer ───
    lock_acquire || return 1
    trap 'lock_release' RETURN

    # 1. Pre-checkpoint
    if ! checkpoint_run "$current"; then
        echo "⛔ TRANSFER ABORTED — pre-checkpoint did not pass" >&2
        echo "  Reason: $SYNCCTL_CHECKPOINT_REASON" >&2
        echo "  Master remains: $current"
        audit_log "transfer" "from=$current" "to=$target" "result=aborted" "reason=$SYNCCTL_CHECKPOINT_REASON"
        return 1
    fi
    local pre_chk="$SYNCCTL_CHECKPOINT_ID"

    state_handover_begin "$current" "$target" 1 "$pre_chk"

    # 2. PHASE A: re-verify target in-sync (TOCTOU guard)
    if ! get_completion "$target" >/dev/null 2>&1; then
        if [[ "$force" != "1" ]]; then
            echo "⛔ TRANSFER ABORTED — target '$target' unreachable" >&2
            state_handover_complete
            return 1
        fi
    fi
    state_handover_step 2

    # 3. PHASE B: promote target FIRST
    if ! promote_to_master "$target"; then
        echo "⛔ TRANSFER ABORTED — could not promote $target" >&2
        state_handover_complete
        return 1
    fi
    state_handover_step 3

    # 4. Demote all others (including old master)
    for dev in $(syncctl_list_devices); do
        [[ "$dev" == "$target" ]] && continue
        demote_from_master "$dev" || {
            echo "⚠️  Failed to demote $dev (continuing anyway)" >&2
        }
    done
    state_handover_step 4

    # 5. Update master pointers
    state_set_local_master "$target"
    state_set_synced_master "$target"
    state_handover_step 5

    # 6. Post-checkpoint
    if ! checkpoint_run "$target"; then
        echo "⚠️  Post-checkpoint failed (master=$target applied but cluster may not be clean)" >&2
    fi
    state_handover_step 6

    state_handover_complete
    audit_log "transfer" "from=$current" "to=$target" "result=ok" \
        "checkpoint=#$pre_chk" "reason=$reason" "force=$force"
    echo "✅ Transfer complete: $current → $target"
    return 0
}

# ──────────────────────────────────────────────────────────
# recover_stale_handover
# Called when state.json shows stale handover
# ──────────────────────────────────────────────────────────
recover_stale_handover() {
    state_json_init_if_missing
    local in_progress from to step started_at
    in_progress="$(state_json_get handover_in_progress)"
    [[ "$in_progress" == "true" ]] || { echo "No stale handover."; return 0; }

    from="$(state_json_get from)"
    to="$(state_json_get to)"
    step="$(state_json_get step)"
    started_at="$(state_json_get started_at)"

    echo "⚠️  STALE HANDOVER"
    echo "  Started: $started_at"
    echo "  From: $from → To: $to"
    echo "  Last step: $step"
    echo ""
    echo "  1) ABORT    — rollback, mark idle"
    echo "  2) CONTINUE — re-run transfer (will re-verify)"
    echo "  3) STATUS   — current cluster state"
    echo ""
    read -r -p "Choice [1/2/3]: " ch
    case "$ch" in
        1) state_handover_complete
           audit_log "recover" "action=abort" "from=$from" "to=$to"
           echo "✅ Marked idle. Master remains: $from"
           ;;
        2) transfer_master "$to" --reason "recovery from stale" ;;
        3) echo "(Run: syncctl status)" ;;
        *) echo "Invalid."; return 1 ;;
    esac
}
