#!/bin/bash
# ============================================================
# syncctl/lib/config.sh — Device registry + paths
# ============================================================
# Reuses SSOT from ~/bashscripts/00-env.sh (NODE_*, ST_KEY_*)
# Adds syncctl-specific config (paths, version, defaults)
#
# This file is sourced by every other syncctl lib.
# ============================================================

# Guard: prevent double-source
[[ -n "${_SYNCCTL_CONFIG_LOADED:-}" ]] && return 0
export _SYNCCTL_CONFIG_LOADED=1

# ──────────────────────────────────────────────────────────
# Paths
# ──────────────────────────────────────────────────────────
export SYNCCTL_HOME="${SYNCCTL_HOME:-$HOME/.local/share/syncctl}"
export SYNCCTL_STATE="$SYNCCTL_HOME/state.json"
export SYNCCTL_LOCK_FILE="$SYNCCTL_HOME/syncctl.lock"
export SYNCCTL_AUDIT_LOG="$SYNCCTL_HOME/audit.log"
export SYNCCTL_CHECKPOINT_DIR="$SYNCCTL_HOME/checkpoints"
export SYNCCTL_CONFLICT_ARCHIVE="$SYNCCTL_HOME/conflicts"
export SYNCCTL_LOCAL_MASTER_FILE="$SYNCCTL_HOME/master"

# Synced .syncctl/ directory inside the controlled folder
# Default: same folder as bashscripts → allows per-folder ownership
export SYNCCTL_FOLDER_ROOT="${SYNCCTL_FOLDER_ROOT:-$SSOT}"
export SYNCCTL_SYNCED_MASTER_DIR="$SYNCCTL_FOLDER_ROOT/.syncctl"
export SYNCCTL_SYNCED_MASTER_FILE="$SYNCCTL_SYNCED_MASTER_DIR/master"

# Folder ID in Syncthing (default: bashscripts folder)
# Must match the `id` in Syncthing's config.xml for this folder
export SYNCCTL_FOLDER_ID="${SYNCCTL_FOLDER_ID:-bashscripts}"

# ──────────────────────────────────────────────────────────
# Device registry
# ──────────────────────────────────────────────────────────
# Map: device name → Syncthing device ID
# Source of truth = 00-env.sh (NODE_*_ST_ID)
# We re-export here as an associative array for easy lookup.

declare -gA SYNCCTL_DEVICES=()

# Auto-populate from NODE_*_ST_ID if 00-env.sh was sourced
[[ -n "$NODE_WSL_ST_ID" ]]    && SYNCCTL_DEVICES[wsl]="$NODE_WSL_ST_ID"
[[ -n "$NODE_WIN_ST_ID" ]]    && SYNCCTL_DEVICES[windows]="$NODE_WIN_ST_ID"
[[ -n "$NODE_TERMUX_ST_ID" ]] && SYNCCTL_DEVICES[termux]="$NODE_TERMUX_ST_ID"
[[ -n "$NODE_MUMU_ST_ID" ]]   && SYNCCTL_DEVICES[mumu]="$NODE_MUMU_ST_ID"

# Map: device name → ST API base URL
declare -gA SYNCCTL_API_URLS=()
[[ -n "$NODE_WSL_ST_URL" ]]    && SYNCCTL_API_URLS[wsl]="$NODE_WSL_ST_URL"
[[ -n "$NODE_WIN_ST_URL" ]]    && SYNCCTL_API_URLS[windows]="$NODE_WIN_ST_URL"
[[ -n "$NODE_TERMUX_ST_URL" ]] && SYNCCTL_API_URLS[termux]="$NODE_TERMUX_ST_URL"
[[ -n "$NODE_MUMU_ST_URL" ]]   && SYNCCTL_API_URLS[mumu]="$NODE_MUMU_ST_URL"

# Map: device name → ST API key (loaded from ST_KEY_*)
declare -gA SYNCCTL_API_KEYS=()
[[ -n "$ST_KEY_WSL" ]]    && SYNCCTL_API_KEYS[wsl]="$ST_KEY_WSL"
[[ -n "$ST_KEY_WIN" ]]    && SYNCCTL_API_KEYS[windows]="$ST_KEY_WIN"
[[ -n "$ST_KEY_TERMUX" ]] && SYNCCTL_API_KEYS[termux]="$ST_KEY_TERMUX"
[[ -n "$ST_KEY_MUMU" ]]   && SYNCCTL_API_KEYS[mumu]="$ST_KEY_MUMU"

# Local device name (this machine's identifier)
# Detected from JOE_ENV → maps to our registry name
case "${JOE_ENV:-}" in
    WSL)      export SYNCCTL_LOCAL_DEVICE="wsl" ;;
    GIT-BASH) export SYNCCTL_LOCAL_DEVICE="windows" ;;
    TERMUX)   export SYNCCTL_LOCAL_DEVICE="termux" ;;
    MUMU)     export SYNCCTL_LOCAL_DEVICE="mumu" ;;
    *)        export SYNCCTL_LOCAL_DEVICE="unknown" ;;
esac

# Local ST API URL (for querying self)
export SYNCCTL_LOCAL_API_URL="${SYNCCTL_API_URLS[$SYNCCTL_LOCAL_DEVICE]:-}"
export SYNCCTL_LOCAL_API_KEY="${SYNCCTL_API_KEYS[$SYNCCTL_LOCAL_DEVICE]:-}"

# ──────────────────────────────────────────────────────────
# Timeout / retry defaults
# ──────────────────────────────────────────────────────────
export SYNCCTL_API_TIMEOUT="${SYNCCTL_API_TIMEOUT:-10}"     # seconds
export SYNCCTL_API_RETRY="${SYNCCTL_API_RETRY:-2}"          # attempts
export SYNCCTL_INSYNC_TIMEOUT="${SYNCCTL_INSYNC_TIMEOUT:-60}"  # wait for in-sync
export SYNCCTL_HANDOVER_STALE_TIMEOUT="${SYNCCTL_HANDOVER_STALE_TIMEOUT:-300}"  # 5min

# ──────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────

# Initialize directories (idempotent)
syncctl_init_paths() {
    mkdir -p "$SYNCCTL_HOME" \
             "$SYNCCTL_CHECKPOINT_DIR" \
             "$SYNCCTL_CONFLICT_ARCHIVE"
    [[ -f "$SYNCCTL_AUDIT_LOG" ]] || : > "$SYNCCTL_AUDIT_LOG"
}

# List known device names
syncctl_list_devices() {
    printf '%s\n' "${!SYNCCTL_DEVICES[@]}" | sort
}

# Validate that a device name is known
# Returns 0 if known, 1 if unknown
syncctl_is_known_device() {
    local name="$1"
    [[ -n "${SYNCCTL_DEVICES[$name]:-}" ]]
}

# Get device ID by name
syncctl_get_device_id() {
    local name="$1"
    printf '%s' "${SYNCCTL_DEVICES[$name]:-}"
}

# Get API URL by device name
syncctl_get_api_url() {
    local name="$1"
    printf '%s' "${SYNCCTL_API_URLS[$name]:-}"
}

# Get API key by device name
syncctl_get_api_key() {
    local name="$1"
    printf '%s' "${SYNCCTL_API_KEYS[$name]:-}"
}
