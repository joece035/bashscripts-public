#!/bin/bash
# ============================================================
# syncctl/lib/checkpoint.sh — Checkpoint engine
# ============================================================
# Pre-condition for any transfer.
# Checks (per spec section 3):
#   3.1 Local state
#   3.2 Syncthing sync state
#   3.3 Cluster state (all peers in-sync)
#   3.4 Conflict detection (.sync-conflict-* files)
# Produces:
#   - SYNCCTL_CHECKPOINT_ID  (e.g. "0042")
#   - Audit log entry
#   - $SYNCCTL_CHECKPOINT_DIR/<id>.json
# ============================================================

# Guard
[[ -n "${_SYNCCTL_CHECKPOINT_LOADED:-}" ]] && return 0
export _SYNCCTL_CHECKPOINT_LOADED=1

source "$(dirname "${BASH_SOURCE[0]}")/config.sh"
source "$(dirname "${BASH_SOURCE[0]}")/api.sh"
source "$(dirname "${BASH_SOURCE[0]}")/state.sh"

# Globals set by checkpoint_run()
export SYNCCTL_CHECKPOINT_ID=""
export SYNCCTL_CHECKPOINT_RESULT="fail"   # pass | fail
export SYNCCTL_CHECKPOINT_REASON=""

# ──────────────────────────────────────────────────────────
# Next checkpoint ID: read counter, increment
# ──────────────────────────────────────────────────────────
_next_checkpoint_id() {
    local counter_file="$SYNCCTL_HOME/checkpoint.counter"
    local n=0
    [[ -f "$counter_file" ]] && n="$(<"$counter_file")"
    n=$(( n + 1 ))
    printf '%s' "$n" > "$counter_file"
    printf '%04d' "$n"
}

# ──────────────────────────────────────────────────────────
# Check 3.1: Local state
# Are there any local .sync-conflict-* files? (Defensive)
# ──────────────────────────────────────────────────────────
check_local_state() {
    local conflicts
    conflicts="$(find "$SYNCCTL_FOLDER_ROOT" -name '*.sync-conflict-*' -type f 2>/dev/null | head -5)"
    if [[ -n "$conflicts" ]]; then
        SYNCCTL_CHECKPOINT_REASON="local conflict files: $(echo "$conflicts" | wc -l)"
        return 1
    fi
    return 0
}

# ──────────────────────────────────────────────────────────
# Check 3.2 + 3.3: Syncthing cluster state
# For each known device: query /rest/db/completion
#   completion == 100 → in-sync
#   completion < 100  → out of sync
# Also: skip if device API unreachable (peer offline)
# ──────────────────────────────────────────────────────────
check_cluster_state() {
    local dev
    local failed=()
    local pending=()
    local all_devices=()

    for dev in $(syncctl_list_devices); do
        all_devices+=("$dev")
        if ! get_completion "$dev" >/dev/null 2>&1; then
            # API unreachable — treat as offline (warn, not fail)
            pending+=("$dev (offline/unreachable)")
            continue
        fi
        local body="$SYNCCTL_API_BODY"
        local pct
        pct="$(echo "$body" | jq -r '.completion // empty' 2>/dev/null)"
        if [[ -z "$pct" ]]; then
            failed+=("$dev (no completion data)")
        elif (( $(echo "$pct < 100" | bc -l 2>/dev/null || echo 0) )); then
            pending+=("$dev (${pct}%)")
        fi
    done

    if (( ${#pending[@]} > 0 )); then
        SYNCCTL_CHECKPOINT_REASON="out of sync: ${pending[*]}"
        return 1
    fi
    if (( ${#failed[@]} > 0 )); then
        SYNCCTL_CHECKPOINT_REASON="cluster state errors: ${failed[*]}"
        return 1
    fi
    return 0
}

# ──────────────────────────────────────────────────────────
# Check 3.4: Conflicts via API
# Look at /rest/folder/errors for this folder
# ──────────────────────────────────────────────────────────
check_conflicts() {
    local dev conflict_count=0
    for dev in $(syncctl_list_devices); do
        if ! get_folder_errors "$dev" >/dev/null 2>&1; then
            continue   # skip offline
        fi
        local body="$SYNCCTL_API_BODY"
        local cnt
        cnt="$(echo "$body" | jq -r --arg f "$SYNCCTL_FOLDER_ID" \
            '.[$f] // [] | length' 2>/dev/null || echo 0)"
        (( conflict_count += cnt ))
    done

    if (( conflict_count > 0 )); then
        SYNCCTL_CHECKPOINT_REASON="API-reported conflicts: $conflict_count"
        return 1
    fi
    return 0
}

# ──────────────────────────────────────────────────────────
# Check folder type invariant
# Master folder MUST be sendonly, others MUST be receiveonly
# ──────────────────────────────────────────────────────────
check_folder_types() {
    local master="$1"
    local dev type bad=()
    for dev in $(syncctl_list_devices); do
        if ! get_folder_config "$dev" >/dev/null 2>&1; then
            continue
        fi
        type="$(echo "$SYNCCTL_API_BODY" | jq -r '.type // empty' 2>/dev/null)"
        if [[ "$dev" == "$master" ]]; then
            [[ "$type" == "sendonly" ]] || bad+=("$dev (expected sendonly, got $type)")
        else
            [[ "$type" == "receiveonly" ]] || bad+=("$dev (expected receiveonly, got $type)")
        fi
    done
    if (( ${#bad[@]} > 0 )); then
        SYNCCTL_CHECKPOINT_REASON="folder type mismatch: ${bad[*]}"
        return 1
    fi
    return 0
}

# ──────────────────────────────────────────────────────────
# checkpoint_run [master_device]
# Runs all checks, writes checkpoint file, audits.
# Sets globals: SYNCCTL_CHECKPOINT_ID, SYNCCTL_CHECKPOINT_RESULT
# Returns: 0 on pass, 1 on fail
# ──────────────────────────────────────────────────────────
checkpoint_run() {
    local master="${1:-}"
    [[ -z "$master" ]] && {
        local line
        line="$(state_reconcile_master)"
        master="${line#master=}"
        master="${master%%|*}"
    }

    syncctl_init_paths
    local start_ms; start_ms="$(date +%s%3N 2>/dev/null || date +%s)000"

    local checks_passed=0 checks_total=0
    local failures=()

    # Run checks
    for check in check_local_state check_cluster_state check_conflicts; do
        (( checks_total++ )) || true
        if "$check"; then
            (( checks_passed++ )) || true
        else
            failures+=("$check: $SYNCCTL_CHECKPOINT_REASON")
        fi
    done

    # Folder type check (only if master known)
    if [[ -n "$master" ]]; then
        (( checks_total++ )) || true
        if check_folder_types "$master"; then
            (( checks_passed++ )) || true
        else
            failures+=("check_folder_types: $SYNCCTL_CHECKPOINT_REASON")
        fi
    fi

    local id; id="$(_next_checkpoint_id)"
    local end_ms; end_ms="$(date +%s%3N 2>/dev/null || date +%s)000"
    local duration=$(( end_ms - start_ms ))
    local result; result="fail"
    [[ ${#failures[@]} -eq 0 ]] && result="pass"

    # Write checkpoint file
    local ckpt_file="$SYNCCTL_CHECKPOINT_DIR/${id}.json"
    jq -n \
        --arg id "$id" \
        --arg master "$master" \
        --arg folder "$SYNCCTL_FOLDER_ID" \
        --arg result "$result" \
        --argjson passed "$checks_passed" \
        --argjson total "$checks_total" \
        --argjson duration "$duration" \
        --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        '{
            id: $id,
            master: $master,
            folder: $folder,
            result: $result,
            checks_passed: $passed,
            checks_total: $total,
            duration_ms: $duration,
            timestamp: $ts,
            failures: $failures
        }' \
        --argjson failures "$(printf '%s\n' "${failures[@]}" | jq -R . | jq -s . 2>/dev/null || echo '[]')" \
        > "$ckpt_file" 2>/dev/null || {
            # Fallback without nested failures
            jq -n \
                --arg id "$id" --arg master "$master" --arg folder "$SYNCCTL_FOLDER_ID" \
                --arg result "$result" --argjson passed "$checks_passed" --argjson total "$checks_total" \
                --arg ts "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
                '{id:$id,master:$master,folder:$folder,result:$result,checks_passed:$passed,checks_total:$total,timestamp:$ts}'
                > "$ckpt_file"
        }

    SYNCCTL_CHECKPOINT_ID="$id"
    SYNCCTL_CHECKPOINT_RESULT="$result"

    # Audit
    audit_log "checkpoint" "id=#$id" "master=$master" "result=$result" \
        "checks=$checks_passed/$checks_total" "duration_ms=$duration"

    [[ "$result" == "pass" ]] && return 0 || return 1
}

# ──────────────────────────────────────────────────────────
# list_checkpoints [limit]
# ──────────────────────────────────────────────────────────
list_checkpoints() {
    local limit="${1:-10}"
    ls -1t "$SYNCCTL_CHECKPOINT_DIR"/*.json 2>/dev/null | head -n "$limit" | while read -r f; do
        jq -r '"\(.id) \(.result) \(.timestamp) master=\(.master)"' "$f" 2>/dev/null
    done
}
